package br.com.ifgoias.aulajpa;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;


@Entity
public class Marca implements Serializable{
	
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Integer idmarca;
	private String nome;
	
	@OneToMany (mappedBy = "Modelo")
	private List<Modelo> Modelo;

	
	
	public Marca(Integer idmarca, String nome) {
		
		this.idmarca = idmarca;
		this.nome = nome;
	}

	public Integer getIdmarca() {
		return idmarca;
	}

	public void setIdmarca(Integer idmarca) {
		this.idmarca = idmarca;
	}

	public List<Modelo> getModelo() {
		return Modelo;
	}

	public void setModelo(List<Modelo> modelo) {
		Modelo = modelo;
	}
	
	
}
