package br.com.ifgoias.aulajpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Aplicacao {

	public static void main(String[] args) {
		
		
		EntityManagerFactory teste = Persistence.createEntityManagerFactory("aulajpa");
		EntityManager Teste = teste.createEntityManager();

		Teste.getTransaction().begin();
	}

}
