package br.com.ifgoias.aulajpa;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Automovel implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue (strategy = GenerationType.IDENTITY)
	private Integer idautomovel;
	private Integer anoFabricacao;
	private Integer anoModelo;
	private String observacoes;
	private Float preco;
	private Integer kilometragem;
	
	@ManyToOne
	@JoinColumn(name = "idmodelo")
	private Modelo Modelo;

	
	
	public Automovel(Integer idautomovel, Integer anoFabricacao, Integer anoModelo, String observacoes, Float preco,
			Integer kilometragem) {
		this.idautomovel = idautomovel;
		this.anoFabricacao = anoFabricacao;
		this.anoModelo = anoModelo;
		this.observacoes = observacoes;
		this.preco = preco;
		this.kilometragem = kilometragem;
	}

	public Integer getIdautomovel() {
		return idautomovel;
	}

	public void setIdautomovel(Integer idautomovel) {
		this.idautomovel = idautomovel;
	}

	public Integer getAnoFabricacao() {
		return anoFabricacao;
	}

	public void setAnoFabricacao(Integer anoFabricacao) {
		this.anoFabricacao = anoFabricacao;
	}

	public Integer getAnoModelo() {
		return anoModelo;
	}

	public void setAnoModelo(Integer anoModelo) {
		this.anoModelo = anoModelo;
	}

	public String getObservacoes() {
		return observacoes;
	}

	public void setObservacoes(String observacoes) {
		this.observacoes = observacoes;
	}

	public Float getPreco() {
		return preco;
	}

	public void setPreco(Float preco) {
		this.preco = preco;
	}

	public Integer getKilometragem() {
		return kilometragem;
	}

	public void setKilometragem(Integer kilometragem) {
		this.kilometragem = kilometragem;
	}
	
	
}
